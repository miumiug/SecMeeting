package main

import (
	"golang.org/x/net/http2"
	"golang.org/x/net/http2/hpack"

	"bytes"
	"crypto/tls"
	"io"
	"log"
	"math/rand"
	"net/http"
	"os"
	"strconv"
	"strings"
)

func main() {
	// check args
	if len(os.Args) < 6 {
		log.Fatal("Usage: " + os.Args[0] + " <dialback[:port]> <[listner]:port> <protocall-list,[...]> <cert> <key>")
	}

	config := &tls.Config{
		ServerName:         os.Args[1],
		NextProtos:         strings.Split(os.Args[3], ","),
		InsecureSkipVerify: true,
	}

	// global map of outbound streams to incomming H1 request responses
	streamTable := make(map[int32]http.ResponseWriter)

	// define http handle for proxy server
	http.HandleFunc("/",

		func(w http.ResponseWriter, r *http.Request) {

			// transform HTTP request (r) -> HTTP2 request
			var h2Req bytes.Buffer
			hpackEncoder := hpack.NewEncoder(&h2Req)
			hpackEncoder.WriteField(hpack.HeaderField{Name: ":authority", Value: r.Host}) // probably not right for all sites
			hpackEncoder.WriteField(hpack.HeaderField{Name: ":method", Value: r.Method})
			hpackEncoder.WriteField(hpack.HeaderField{Name: ":path", Value: r.URL.Path})
			hpackEncoder.WriteField(hpack.HeaderField{Name: ":scheme", Value: "https"})
			for key, values := range r.Header {
				lowKey := strings.ToLower(key)
				if lowKey == "host" {
					continue
				}
				for _, value := range values {
					hpackEncoder.WriteField(hpack.HeaderField{Name: lowKey, Value: value})
				}
			}
			if len(h2Req.Bytes()) > 16<<10 {
				log.Println("TODO: h2mp doesn't yet write CONTINUATION frames. Copy it from transport.go")
				return
			}

			// connect to dialback
			log.Printf("Connecting to %s ...\n", os.Args[1])
			socket, err := tls.Dial("tcp", os.Args[1], config)
			if err != nil {
				log.Println(err)
				return
			}
			log.Printf("Connected to %v\n", socket.RemoteAddr())
			defer socket.Close()

			// check handshake
			if err := socket.Handshake(); err != nil {
				log.Println(err)
				return
			}

			// check connection state
			if !socket.ConnectionState().NegotiatedProtocolIsMutual {
				log.Println("NegotiatedProtocolIsMutual is False")
				return
			}
			if socket.ConnectionState().NegotiatedProtocol == "" {
				log.Println("NegotiatedProtocol is empty")
				return
			}
			log.Printf("Negotiated protocol %q", socket.ConnectionState().NegotiatedProtocol)

			// transmit HTTP2 client preface
			log.Printf("Sending Client Preface")
			if _, err := io.WriteString(socket, http2.ClientPreface); err != nil {
				log.Println(err)
				return
			}

			// create HTTP2 Framer
			log.Printf("Creating Framer")
			framer := http2.NewFramer(socket, socket)

			// send settings frame
			if err := framer.WriteSettingsAck(); err != nil {
				log.Println(err)
				return
			}

			// pick an unused stream ID
			var streamID int32
			for {
				streamID = rand.Int31n(65535)
				if _, ok := streamTable[streamID]; ok {
					continue
				}
				streamTable[streamID] = w
				break
			}

			// write H2 request
			framer.WriteHeaders(
				http2.HeadersFrameParam{
					StreamID:      uint32(streamID),
					BlockFragment: h2Req.Bytes(),
					EndStream:     r.Method == "GET" || r.Method == "HEAD", // good enough for now
					EndHeaders:    true,                                    // for now
				},
			)

			// create containers to store response data
			var pageData []byte

			// read frames untill we get the "goAway" signal
			var hpackDecoder *hpack.Decoder
			peerSetting := make(map[http2.SettingID]uint32)
			streamDone := false
			for {
				if streamDone {
					break
				}
				frame, err := framer.ReadFrame()
				if err != nil {
					log.Println(err)
					break // TODO: should be continue until timeout
				}
				switch frame := frame.(type) {
				case *http2.PingFrame:
					log.Println("  Data = %q", frame.Data)
				case *http2.SettingsFrame:
					frame.ForeachSetting(func(s http2.Setting) error {
						log.Println("  %v", s)
						peerSetting[s.ID] = s.Val
						return nil
					})
				case *http2.WindowUpdateFrame:
					log.Println("  Window-Increment = %v", frame.Increment)
				case *http2.GoAwayFrame:
					log.Println("  Last-Stream-ID = %d; Error-Code = %v (%d)", frame.LastStreamID, frame.ErrCode, frame.ErrCode)
					streamDone = true
				case *http2.DataFrame:
					thisStreamID := frame.StreamID
					log.Println("-------------------- START DATA STREAM %d  --------------------------------", thisStreamID)
					log.Println("  %q", string(frame.Data()))
					log.Println("---------------------END DATA--------------------------------")

					// append to buffer holding return H1 data
					pageData = append(pageData, frame.Data()...)

					// check if the server is done
					if frame.StreamEnded() {
						streamDone = true
					}
				case *http2.HeadersFrame:
					if frame.HasPriority() {
						log.Println("  PRIORITY = %v", frame.Priority)
					}
					if hpackDecoder == nil {
						// TODO: if the user uses h2mp to send a SETTINGS frame advertising
						// something larger, we'll need to respect SETTINGS_HEADER_TABLE_SIZE
						// and stuff here instead of using the 4k default. But for now:
						tableSize := uint32(4 << 10)
						hpackDecoder = hpack.NewDecoder(tableSize, func(frame hpack.HeaderField) {
							if frame.Sensitive {
								log.Println("  %s = %q (SENSITIVE)", frame.Name, frame.Value)
							}
							log.Println("  %s = %q", frame.Name, frame.Value)
							var h1Key string
							var h1Value string
							if frame.Name[:1] == ":" {
								h1Key = frame.Name[1:]
							} else {
								h1Key = frame.Name
							}
							h1Value = frame.Value
							w.Header().Add(h1Key, h1Value)
						})
					}
					log.Println("--------------------- START HEADER --------------------------------")
					hpackDecoder.Write(frame.HeaderBlockFragment())
					log.Println("--------------------- END HEADER --------------------------------")
					frame.HeaderBlockFragment()
				}
			}
			if value, err := strconv.ParseInt(w.Header().Get("Status"), 10, 16); err != nil {
				log.Println(err)
			} else {
				w.WriteHeader(int(value))
			}
			w.Write(pageData)
		},
	)
	log.Fatal(http.ListenAndServeTLS(os.Args[2], os.Args[4], os.Args[5], nil))
}
