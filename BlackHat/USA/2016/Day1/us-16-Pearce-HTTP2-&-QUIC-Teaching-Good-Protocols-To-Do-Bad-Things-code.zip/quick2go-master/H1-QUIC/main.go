package main

import (
	"github.com/devsisters/goquic"

	"io"
	"log"
	"net/http"
	"os"
)

func main() {
	// check args
	if len(os.Args) < 3 {
		log.Fatal("Usage: " + os.Args[0] + " <dialback[:port]> <listner:port>")
	}

	// create QUIC client
	client := &http.Client{
		Transport: goquic.NewRoundTripper(false),
	}

	// define http handle for proxy server
	http.HandleFunc("/",

		func(w http.ResponseWriter, r *http.Request) {

			/*// DEBUG =>
			log.Println("*** INCOMING REQUEST:")
			requestBytes, err := httputil.DumpRequest(r, true)
			if err != nil {
				w.Write([]byte(err.Error() + "\n"))
				log.Println(err)
				return
			}
			log.Printf("%s", requestBytes)
			// <= DEBUG */

			// create QUIC request object
			request, err := http.NewRequest(r.Method, "http://"+os.Args[1]+r.URL.String(), r.Body)
			if err != nil {
				log.Println(err)
				return
			}

			// copy HTTP request data to QUIC request object
			for key, values := range r.Header {
				for _, value := range values {
					request.Header.Add(key, value)
				}
			}

			/*// DEBUG =>
			log.Println("*** OUTGOING REQUEST:")
			requestBytes, err = httputil.DumpRequest(request, true)
			if err != nil {
				w.Write([]byte(err.Error() + "\n"))
				log.Println(err)
				return
			}
			log.Printf("%s", requestBytes)
			// <= DEBUG*/

			// send QUIC request
			resp, err := client.Do(request)
			if err != nil {
				w.Write([]byte(err.Error() + "\n"))
				log.Println(err)
				return
			}

			// copy QUIC client result as HTTP response
			for key, values := range resp.Header {
				for _, value := range values {
					w.Header().Add(key, value)
				}
			}
			w.WriteHeader(resp.StatusCode)
			io.Copy(w, resp.Body)
		},
	)

	// setart proxy server
	log.Fatal(http.ListenAndServe(os.Args[2], nil))
}
