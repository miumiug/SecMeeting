package main

import (
	"github.com/devsisters/goquic"
	"io"
	"log"
	"net/http"
	"os"
)

func main() {
	// check args
	if len(os.Args) < 5 {
		log.Fatal("Usage: " + os.Args[0] + " <cert file> <key file> <dialback[:port]> <listner:port>")
	}

	// create HTTP client
	client := &http.Client{}

	// define http handle for proxy server
	http.HandleFunc("/",

		func(w http.ResponseWriter, r *http.Request) {

			/*// DEBUG =>
			log.Println("*** INCOMING REQUEST:")
			requestBytes, err := httputil.DumpRequest(r, true)
			if err != nil {
				log.Println(err)
				return
			}
			log.Printf("%s", requestBytes)
			// <= DEBUG*/

			// create HTTP request object
			request, err := http.NewRequest(r.Method, r.URL.Scheme+"://"+os.Args[3]+r.URL.Path, r.Body)
			if err != nil {
				log.Println(err)
				return
			}

			// copy HTTP request data to QUIC request object
			for key, values := range r.Header {
				for _, value := range values {
					request.Header.Add(key, value)
				}
			}

			/*// DEBUG =>
			log.Println("*** OUTGOING REQUEST:")
			requestBytes, err = httputil.DumpRequest(request, true)
			if err != nil {
				log.Println(err)
				return
			}
			log.Printf("%s", requestBytes)
			// <= DEBUG*/

			// send QUIC request
			resp, err := client.Do(request)
			if err != nil {
				w.Write([]byte(err.Error()))
				log.Println(err)
				return
			}

			// copy result as response
			for key, values := range r.Header {
				for _, value := range values {
					w.Header().Add(key, value)
				}
			}
			w.WriteHeader(resp.StatusCode)
			io.Copy(w, resp.Body)
		},
	)

	// setart proxy server
	log.Fatal(goquic.ListenAndServeQuicSpdyOnly(os.Args[4], os.Args[1], os.Args[2], 1, nil))
}
