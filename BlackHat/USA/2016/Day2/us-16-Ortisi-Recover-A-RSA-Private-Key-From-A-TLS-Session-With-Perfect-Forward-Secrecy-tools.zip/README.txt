=======================
High Voltage & Piciolla
=======================
For a full explanation of how the tools work or further details about the attack 
technique used, read the attached PDF whitepaper. The tools must be compiled
with:

$ gcc hv.c -o hv -lcrypto -lssl
$ gcc piciolla.c -o piciolla -lcrypto -lssl

Tested on CentOS 6.x / 7.x and Kali Linux 2.0

For piciolla only: the pcaps directory contains samples of network dump files that
leak out the server private key. A description of how to set up a test environment
for High Voltage is explained into the Whitepaper.

