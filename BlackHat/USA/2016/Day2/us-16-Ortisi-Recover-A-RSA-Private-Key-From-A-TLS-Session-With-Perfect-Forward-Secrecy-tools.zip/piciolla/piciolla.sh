#!/bin/bash

if [ -z "$1" ]; then
   echo "please specify the directory of tcpflow streams"
   exit 0
fi

WORK_DIR=$1/*

if [ ! -d ./incomplete ]
then
   mkdir ./incomplete
fi

if [ ! -d ./not_tls ]
then
   mkdir ./not_tls
fi

IS_TLS_WITH_CLIENT_HELLO="16 03 01 03"
IS_CLIENT_HELLO="01"

function launch
{
   echo "   dir is $1"
   echo "   file1 is $2"
   echo "   file2 is $3"

   # is file1 a TLS session client-side?
   check_tls_file1=`hexdump -C $1/$2 | cut -d " " -f 3,4,8,13 | head -n 1`
   check_tls_file2=`hexdump -C $1/$3 | cut -d " " -f 3,4,8,13 | head -n 1`

   if [ "$check_tls_file1" == "$IS_TLS_WITH_CLIENT_HELLO" ];
   then
      echo "   $2 is our TLS session client -> server"
      ./piciolla $1/$2 $1/$3
      echo
   elif [ "$check_tls_file2" == "$IS_TLS_WITH_CLIENT_HELLO" ]; then
      echo "   $3 is our TLS session client -> server"
      ./piciolla $1/$3 $1/$2
      echo
   else
      echo "   This is not a TLS session"
      echo
      cp -p $1/$2 ./not_tls
      cp -p $1/$3 ./not_tls
   fi
}

# MAIN BODY

for file in $WORK_DIR;
do
   echo processing $file
   # streams are two (client -> server and server->client)

   file_stream=`echo $file | sed 's/.*\///' | cut -d "-" -f 1`
   
   n_file=`ls -la $1 | grep $file_stream | cat -n | tail -f -n 1 | cut -f 1`
   if [ $n_file -ne 2 ];
   then
      file_stream=`echo $file | sed 's/.*\///' | cut -d "-" -f 2`
      n_file=`ls -la $1 | grep $file_stream | cat -n | tail -f -n 1 | cut -f 1`

      if [ $n_file -ne 2 ];
      then
         #discharge this file. Not a full-duplex TCP communication
         echo "   incomplete: not a full-duplex TCP communication"
         cp -p $file ./incomplete
      else
         # HALLELUIA! We found our file's couple
         file1=`ls $1 | grep $file_stream | head -n 1`
         file2=`ls $1 | grep $file_stream | tail -n 1`
         launch $1 $file1 $file2
      fi

   else
     #echo HALLELUIA_MI_MANCIAI_U_PANINU_CULLINDUIA
     file1=`ls $1 | grep $file_stream | head -n 1`
     file2=`ls $1 | grep $file_stream | tail -n 1`
     launch $1 $file1 $file2
   fi
done

# all files should be moved on not_tls, incomplete, etc... directory
#rm -rf $1/*