# THIS PROGRAM IS TO BE USED FOR EDUCATIONAL PURPOSES ONLY.
# CAN BE USED FOR INTERNAL PEN-TESTING, STAFF RECRUITMENT, SOCIAL ENGAGEMENT

import time
import credentials
import argparse
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

# Wait this long before pages load, in seconds
PAGE_LOAD_TIME = 2


# Posts a new status using Selenium
# Very kludgey, but most UI things are
def post_status(text):
    driver = webdriver.PhantomJS()
    driver.set_window_size(1920, 1080)

    # Log in using provided credentials
    login_page = driver.get("https://mobile.twitter.com/login")
    time.sleep(PAGE_LOAD_TIME)
    email_box = driver.find_element_by_id("session[username_or_email]")
    email_box.send_keys(credentials.username)
    password_box = driver.find_element_by_id("session[password]")
    password_box.send_keys(credentials.password + Keys.RETURN)
    time.sleep(PAGE_LOAD_TIME)

    # Compose and submit the new status
    driver.get("https://mobile.twitter.com/compose/tweet")
    time.sleep(PAGE_LOAD_TIME)
    status_box = driver.find_element_by_tag_name("textarea")
    status_box.click()
    status_box.send_keys(text)
    status_box.submit()
    time.sleep(PAGE_LOAD_TIME)

    # Cleanly shut everything down
    driver.quit()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Posts status to timeline"
                                                 " of user given"
                                                 " in credentials.py")
    parser.add_argument("text", help="text to post")
    args = parser.parse_args()
    post_status(args.text)
