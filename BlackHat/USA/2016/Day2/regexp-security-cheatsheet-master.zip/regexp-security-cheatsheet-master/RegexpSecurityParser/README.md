OWASP CRS rules were collected from [SpiderLabs repository](https://github.com/SpiderLabs/owasp-modsecurity-crs/) in the following way:  
`cat *xss* | grep -P 'SecRule .*$' > CRS3dev-xss.txt`  
and [COMODO WAF](https://waf.comodo.com/) rules:  
`cat * | grep -P 'SecRule.*\/\*(.*)$' > COMODO.txt`  
***

PHP Usage:  
![PHP script usage](http://s8.hostingkartinok.com/uploads/images/2016/05/a5779e75cf53143e3e7cf5c06d26d8d9.png)
***

Output example:  
![Output example](http://oi67.tinypic.com/15344k4.jpg)
