#! /usr/bin/env python
# -*- coding: cp932 -*-


