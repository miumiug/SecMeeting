The latest versions of these tools can be found at https://github.com/PortSwigger/collaborator-everywhere and https://github.com/PortSwigger/hackability
